#!/bin/sh

set -eu

JLinkExe -commanderscript flash.jlink
